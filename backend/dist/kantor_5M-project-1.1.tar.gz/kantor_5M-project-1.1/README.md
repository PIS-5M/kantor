## Test package for artifacts repository
Kantor (Team 5M) project